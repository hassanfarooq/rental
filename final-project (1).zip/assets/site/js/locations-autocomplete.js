var locations = [
{ value: "Santa Monica - 2102 Lincoln Blvd"},
{ value: "Los Angeles - 5711 W Century Blvd"},
{ value: "Las Vegas - 6401 Centennial Center Blvd"},
{ value: "New York - 610 Warren St"},
{ value: "Orlando - 2125 W Landstreet Rd"},
{ value: "Washington - 50 Massachusetts Ave NE"},
{ value: "Denver - 7800 E Tufts Ave"}
];