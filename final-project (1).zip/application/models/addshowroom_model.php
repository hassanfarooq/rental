<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class addshowroom_model extends CI_Model {

    public function selectAllProvinces()
    {
        $sql = "select * from provinces";
        $result = $this->db->query($sql);
        if($result->num_rows() > 0) {
            $result = $result->result_array();
            return $result;
        }
        return false;
    }

    public function selectCitiesByProvinceId($id)
    {
        $sql = "select * from cities where province_id = " . $id;
        $result = $this->db->query($sql);
        if($result->num_rows() > 0) {
            $result = $result->result_array();
            return $result;
        }
        return false;
    }
	public function saveShowroom($data)
	{
		$this->db->insert('showroom', $data); 
	}
	
}