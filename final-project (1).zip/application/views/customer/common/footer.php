<footer class="main-footer">
    <strong>Copyright &copy; 2016-2017 <a href="#">Car Rental System</a>.</strong> All rights
    reserved.
  </footer>
<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url('assets/customer/plugins/jQuery/jquery-2.2.3.min.js'); ?>"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?php echo base_url('assets/customer/plugins/jQuery/jquery-ui.min.js'); ?>"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
    $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url('assets/customer/js/bootstrap.min.js');?> "></script>
<script src="<?php echo base_url('assets/customer/plugins/daterangepicker/moment.min.js');?>"></script>
<script src="<?php echo base_url('assets/customer/plugins/daterangepicker/daterangepicker.js');?>"></script>
<script src="<?php echo base_url('assets/customer/plugins/datepicker/bootstrap-datepicker.js');?>"></script>
<script src="<?php echo base_url('assets/customer/js/app.min.js');?>"></script>
<script src="<?php echo base_url('assets/customer/js/custom.js');?>"></script>

</body>
</html>