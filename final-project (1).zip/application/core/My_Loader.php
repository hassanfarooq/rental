<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class My_Loader extends CI_Loader {

    public function site_template ($view, $data) {
        $this->view('site/common/header');
        $this->view('site/'. $view, $data);
        $this->view('site/common/footer');
    }

    public function customer_template ($view, $data) {
        $this->view('customer/common/header');
        $this->view('customer/common/sidebar');
        $this->view('customer/'. $view, $data);
        $this->view('customer/common/footer');
    }
}