<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Site extends CI_Controller {

	public function __construct(){
		parent::__construct();
	}
}
class Customer extends CI_Controller {

	public function __construct(){
		parent::__construct();
		if(!$this->is_login_customer()){
			redirect(site_url('Customer/Login'));
		}
	}

	public function is_login_customer() {
		$check_session = $this->session->userdata('customer');
		if(isset($check_session) && !empty($check_session)) {
			if($check_session['login'] == true) {
				return true;
			}
		}
		return false;
	}

}