<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Car extends Customer {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('car_model');
	}

	public function index()
	{
		$user_id = $_SESSION['customer']['id'];
		$data = array(
			'showroom_list' => $this->car_model->selectAllShowroomByUserId($user_id),
			'model' => $this->car_model->SelectAllModels(),
			'cars' => $this->car_model->selectAlLCarsByShowroom($user_id)
		);
		
		$this->load->customer_template('cars', $data);
	}
	
	public function selectCitiesByProvinceId($id)
	{
		$data['cities'] = $this->addcar_model->selectCitiesByProvince($id);
		echo json_encode($data);
	}
	public function selectCarByManufacturer($id)
	{
		$data['cars'] = $this->addcar_model->selectCarsByManufacturer($id);
		echo json_encode($data);
	}	
}
