<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Showroom extends Customer {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('showroom_model');
	}

	public function index()
	{
		$user_id = $_SESSION['customer']['id'];
		$data['showroom'] = $this->showroom_model->selectAllShowrooms($user_id);
		$this->load->customer_template('showroom', $data);
	}
	
	public function selectCitiesByProvinceId($id)
	{
		$data['cities'] = $this->addcar_model->selectCitiesByProvince($id);
		echo json_encode($data);
	}
	public function selectCarByManufacturer($id)
	{
		$data['cars'] = $this->addcar_model->selectCarsByManufacturer($id);
		echo json_encode($data);
	}	
}
