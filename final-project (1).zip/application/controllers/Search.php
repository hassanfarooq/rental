<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Search extends Site {
	public function __construct() 
	{
		parent::__construct();
		$this->load->model('search_model');
	}

	public function index()
	{
		$data['items'] = $this->search_model->selectAll();
		$this->load->site_template('search', $data);
	}
	
	public function searchByCriteria()
	{
		if(isset($_GET) || !empty($_GET)) 
		{
			$data = array(
				'province' => $_GET['province-select'],
				'city' => $_GET['city-select'],
				'manufacturer' => $_GET['manufacturer-select'],	
				'car' => $_GET['car-select'],
				'pick-up-date' => $_GET['pick-up-date'],
				'pick-up-time' => $_GET['pick-up-time'],
				'drop-off-date' => $_GET['drop-off-date'],
				'drop-off-time' => $_GET['drop-off-time']
			);
			$data['items'] = $this->search_model->searchByCriteria($data);
			$this->load->site_template('search', $data);
		}
	}
}
