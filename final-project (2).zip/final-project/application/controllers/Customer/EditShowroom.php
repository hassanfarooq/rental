<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class EditShowroom extends Customer {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('editshowroom_model');
	}

	public function edit($id)
	{
		$data = array(
			'showroom' => $this->editshowroom_model->selectById($id),
			'province' => $this->editshowroom_model->selectAllProvinces()
		);
		$this->load->customer_template('editshowroom', $data);
	}
	
	public function selectCitiesByProvinceId($id)
	{
		$data['cities'] = $this->editshowroom_model->selectCitiesByProvinceId($id);
		echo json_encode($data);
	}
}
