<div class="content-wrapper">
    <section class="content-header">
		<div class="row">
			<div class="col-md-10">
				<h1 style="margin-top:0px;">Showroom</h1>
			</div>
			<div class="col-md-2">
				
			</div>
		</div>
    </section>

    <section class="content">        
        <div class="row">
            <div class="col-md-12">
                <div class="box box-primary">
                    <div class="panel-heading">
						<h3 class="panel-title"><i class="fa fa-list"></i> Edit Showroom</h3>
					</div>
                    <div class="panel-body">
						<form action="<?php echo site_url('customer/addshowroom/saveShowroom');?> " method="post" enctype="multipart/form-data" id="form-product">
							<?php foreach($showroom as $row) { ?>
								<div class="form-group">
								<label class="control-label" for="input-model">Showroom Name</label>
								<input type="text" name="showroom_name" value="<?php echo $row['showroom_name']; ?>" placeholder="Showroom Name" id="input-location" class="form-control" autocomplete="off"><ul class="dropdown-menu"></ul>
							</div>
						
							<div class="form-group">
								<label class="control-label" for="input-model">Showroom Owner Name</label>
								<input type="text" name="showroom_owner" value="<?php echo $row['owner_name']; ?>" placeholder="Showroom Owner Name" id="input-location" class="form-control" autocomplete="off"><ul class="dropdown-menu"></ul>
							</div>
						
							<div class="form-group">
								<label class="control-label" for="input-model">Description</label>
								<input type="text" name="description" value="<?php echo $row['description']; ?>" placeholder="Description" id="input-location" class="form-control" autocomplete="off"><ul class="dropdown-menu"></ul>
							</div>
						
							<div class="form-group">
								<label class="control-label" for="input-model">Address</label>
								<input type="text" name="address" value="<?php echo $row['address']; ?>" placeholder="Address" id="input-location" class="form-control" autocomplete="off"><ul class="dropdown-menu"></ul>
							</div>
							<div class="form-group">
								<label class="control-label" for="input-status">Select Province</label>
								<select name="province" id="edit-showroom-select-province" class="form-control">
									<?php 
										foreach($province as $row) { ?>
											<option value="<?php echo $row['provinces_id']; ?>"><?php echo $row['provinces_name']; ?></option>
										<?php }
									?>
								</select>
							</div>							
							<div class="form-group">
								<label class="control-label" for="input-status">Select City</label>
								<select name="city" id="select-city" class="form-control">

								</select>
							</div>
							<div class="form-group">
								<label class="control-label" for="input-status">Status</label>
								<select name="status" id="status" class="form-control">
									<option value="1">Enable</option>
									<option value="0">Disable</option>
								</select>
							</div>
							<?php } ?>
							<input type="submit" value="save" class="pull-right btn btn-primary">
						</form>
					</div>
                </div>
            </div>
        </div>
    </section>
</div>